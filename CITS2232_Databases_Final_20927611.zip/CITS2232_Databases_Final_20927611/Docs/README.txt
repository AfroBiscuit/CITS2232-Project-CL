CITS2232 Databases Project

Domininc Cockman	20927611
Marcus Green		20947214
Alastair Mory		21120848

Our project uses a dataset of Centrelink offices from data.gov.au to implement
what could be used as the basis of an identity management system for Centrelink
staff.

It consists of a MySQL database back end with a PHP and HTML website front end.
We have hosted our site on the AWS with address
ec2-54-252-239-151.ap-southeast-2.compute.amazonaws.com (ppk file attached)
In order to view the website port 80 must be tunnelled over ssh and accessed via
http://localhost/index.html in a web browser.
As of the submission deadline the php on the server was not working, so all
files necessary to run the website locally are attached. This requires a SQL
server and PHP interpreter to be installed on the computer. WAMP was used by us
for this during development (http://www.wampserver.com/en/).